=== FreshSpin FSE ===
Contributors: gracethemes
Tags:blog, news, one-column, two-columns, right-sidebar, block-styles, custom-colors, editor-style, custom-background, custom-menu, featured-images, template-editing, full-site-editing, block-patterns,  threaded-comments, wide-blocks, translation-ready
Requires at least: 5.0
Requires PHP:  5.6
Tested up to: 6.3
License: GNU General Public License version 2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
FreshSpin FSE theme is one of the best themes designed for laundry service websites. Are you looking forward to opening a laundry service business? If yes, it will be incredibly important to create a website for it. Creating a website for your business will enable more people to learn about it and will eventually draw more customers making your business successful. FreshSpin is the perfect choice for laundry services, room cleaning services, house cleaning agencies, and other similar business websites. This laundry service WordPress theme comes fully packed with extensive features to make a website flourish quickly and easily.

== Theme License & Copyright == 

* FreshSpin FSE WordPress Theme, Copyright 2023 Grace Themes 
* FreshSpin FSE is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0 =
* Initial version release

== Resources ==

Theme is Built using the following resource bundles.

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/de/photo/1087835 ( Header Banner image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1613087 (welcome right image)
	https://pxhere.com/en/photo/1334773







= Icon Images =

  * Grace Themes Self Designed icons images:

	assets/images/icon-hdr-phone.png
	assets/images/icon-hdr-email.png
	assets/images/icon-hdr-clock.png
	assets/images/icon01.png
	assets/images/icon02.png
	assets/images/icon03.png
	assets/images/icon04.png
	assets/images/icon05.png
	assets/images/icon06.png
	assets/images/icon07.png


     
For any help you can mail us at support@gracethemes.com