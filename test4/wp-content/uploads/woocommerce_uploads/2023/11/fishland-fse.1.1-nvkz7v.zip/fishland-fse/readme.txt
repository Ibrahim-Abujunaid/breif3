=== Fishland FSE ===
Contributors: gracethemes
Tags:blog, e-Commerce, one-column, two-columns, left-sidebar, right-sidebar, 
block-patterns, block-styles, custom-colors, editor-style, custom-background, custom-logo, 
custom-menu, featured-images, footer-widgets, full-site-editing, block-patterns,  threaded-comments, 
wide-blocks, translation-ready
Requires at least: 5.0
Requires PHP:  5.6
Tested up to: 6.2
License: GNU General Public License version 2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
The Fishland FSE is a versatile WordPress theme for a seafood business, fishing, fish selling, or any other fish-related business. This free Seafood company WordPress theme can take your fish-related business to new heights as it is comprised of some of the most powerful features.
== Theme License & Copyright == 

* Fishland FSE WordPress Theme, Copyright 2023 Grace Themes 
* Fishland FSE is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0 =
* Initial version release

= 1.1 =
* Default logo removed
* Content area all heading manage different font sizes



== Resources ==

Theme is Built using the following resource bundles.

= jQuery Nivo Slider =
* Name of Author: Dev7studios
* Copyright: 2010-2012
* https://github.com/Codeinwp/Nivo-Slider-jQuery
* License: MIT License
* https://github.com/Codeinwp/Nivo-Slider-jQuery/blob/master/license.txt


= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1107871 (Frontpage banner image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/857327 (about us section image)




     
For any help you can mail us at support@gracethemes.com